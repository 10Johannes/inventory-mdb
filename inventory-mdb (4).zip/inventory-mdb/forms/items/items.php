<?php
    
?>
<!-- Modal -->


<div class="modal fade" id="addItems" tabindex="-1" aria-labelledby="addItemsLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addItemsLabel">Items</h5>
      </div>
      <div class="modal-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/categories/add_items.php">
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Item Name" name="item" required>
            <label for="floatingInput">Category Name</label>
          </div>
          <br>
          <button class="w-50 btn btn-sm btn-success center" type="submit" name="submit">Add Item</button>
          </form>
        </main>
      </div>
    </div>
  </div>
</div>