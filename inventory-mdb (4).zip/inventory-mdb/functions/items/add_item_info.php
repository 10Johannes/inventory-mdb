<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit1'])){
        $ISBN = $_POST['ISBN'];
        $location = $_POST['location'];
        $issued_to = $_POST['issued_to'];
        $date_acquired = $_POST['date_acquired'];
        $purchased_value = $_POST['purchased_value'];
        $PO_Ref_No = $_POST['PO_Ref_No'];
        $warranty = $_POST['warranty'];
        $status = $_POST['status'];
        $sql = "INSERT INTO item_info(ISBN,location,issued_to,date_acquired,purchased_value,PO_Ref_No,warranty,status) VALUES ('$ISBN',' $location','$issued_to','$date_acquired','$purchased_value','$PO_Ref_No','$warranty','$status')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Item added successfully');
            window.location.href='../../admin.php';
            </script>";
            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');</script>";
            break;
        }
        } while(false);
    }
?>