<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $description = $_POST['description'];
        $model = $_POST['model'];
        $brand = $_POST['brand'];
        $sql = "INSERT INTO specifications(model,brand,description) VALUES ('$model','$brand','$description')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Item added successfully');
            window.location.href='../../admin.php';
            </script>";
            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');</script>";
            break;
        }
        } while(false);
    }
?>