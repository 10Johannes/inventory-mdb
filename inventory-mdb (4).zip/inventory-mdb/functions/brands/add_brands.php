<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $brand = $_POST['brand'];
        $sql = "INSERT INTO brands(brand) VALUES ('$brand')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Brand added successfully');
                window.location.href='../../brands.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../brands.php';
            </script>";
            break;
        }
        } while(false);
    }
?>