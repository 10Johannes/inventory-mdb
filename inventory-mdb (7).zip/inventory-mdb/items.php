<?php include('database/dbcon.php'); ?>
<?php include_once('layouts/header.php'); ?>
<header>
    <?php include_once('layouts/sidebar.php'); ?>
    <?php include_once('layouts/navbar.php'); ?>
</header>
<main style="margin-top: 58px">
    <div class="container pt-4">
    <!--Section: Statistics with subtitles-->
    <section>
        <div class="row">
          <div class="col-xl-5 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>Add Items</strong>
                </h5>
            </div>
              <div class="card-body">
                <form method="post" class="clearfix" action="functions/items/add_items.php">
                    <div class="form-floating">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <label class="input-group-text" for="inputGroupSelectCategories">Category</label>
                            </div>
                            <?php include('functions/categories/fetch_categories.php'); ?>
                            <select class="custom-select form-control" id="inputGroupSelectCategories" name="categories_id">
                                <option selected>Select Category...</option>
                                <?php foreach($rows_categories as $row_categories){ ?>
                                <option value="<?php echo $row_categories['id']?>"><?php echo $row_categories['category']?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingDescription" placeholder="Description" name="description">
                        <label for="floatingPassword">Description</label>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingModel" placeholder="Model" name="model">
                        <label for="floatingModel">Model</label>
                    </div>
                    <br>
                    <div class="form-floating">
                        <div class="input-group">
                            <div class="input-group-prepend">
                                <label class="input-group-text" for="inputGroupSelectBrands">Brands</label>
                            </div>
                            <?php include('functions/brands/fetch_brands.php'); ?>
                            <select class="custom-select form-control" id="inputGroupSelectBrands"  name="brands_id">
                            <option selected>Select Brand...</option>
                                <?php foreach($rows_brands as $row_brands){ ?>
                                <option value="<?php echo  $row_brands['id']?>"><?php echo  $row_brands['brand']?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingISBN" placeholder="ISBN" name="ISBN">
                        <label for="floatingISBN">Serial No./ISBN</label>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingLocation" placeholder="Location" name="location">
                        <label for="floatingLocation">Location(Bldg/Flr)</label>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingIssuedTo" placeholder="Issued To" name="issued_to">
                        <label for="floatingIssuedTo">Issued To</label>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="datetime-local" class="form-control" id="floatingDateAcquired" placeholder="Date Acquired" name="date_acquired">
                        <label for="floatingDateAcquired">Date Acquired</label>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingPurchasedValue" placeholder="Purchased Value" name="purchased_value">
                        <label for="floatingPurchasedValue">Purchased Value</label>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingPORefNo" placeholder="PO Ref No." name="PO_Ref_No">
                        <label for="floatingPORefNo">PO Ref No.</label>
                    </div>
                    <br>
                    <div class="form-floating">
                        <input type="text" class="form-control" id="floatingWarranty" placeholder="Warranty" name="warranty">
                        <label for="floatingWarranty">Warranty</label>
                    </div>
                    <br>
                    <br>
                    <button class="w-50 btn btn-md btn-success center" type="submit" name="submit">Add Item</button>
                </form>
              </div>
            </div>
          </div>
          <div class="col-xl-7 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>All Items</strong>
                </h5>
            </div>
              <div class="card-body">
              <div class="table-responsive">
              <table class="table table-hover text-nowrap">
              <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Category</th>
                    <th scope="col">Description</th>
                    <th scope="col">Model</th>
                    <th scope="col">Brand</th>
                    <th scope="col">Serial No./ISBN</th>
                    <th scope="col">Location(Bldg/Flr)</th>
                    <th scope="col">Issued To</th>
                    <th scope="col">Date Acquired</th>
                    <th scope="col">Purchased Value</th>
                    <th scope="col">PO Ref No.</th>
                    <th scope="col">Warranty</th>
                    <th scope="col">Status</th>
                    <th scope="col">Remarks</th>
                    <th scope="col">Operation</th>
                  </tr>
                </thead>
                <tbody>
                <?php include("functions/items/fetch_items.php"); ?>
                <?php include("functions/items/fetch_item_info.php"); ?>
                <?php include("functions/categories/fetch_categories.php"); ?>
                <?php include("functions/brands/fetch_brands.php"); ?>
                <?php include("functions/specifications/fetch_specifications.php"); ?>
                <?php if($rows_items !== null){
                foreach($rows_items as $row_items){ 
                    echo "<tr>";
                    echo "<td>".$row_items['id']."</td>"; 
                    foreach($rows_categories as $row_categories){
                            if($row_categories['id']===$row_items['categories_id']){
                                echo "<td>".$row_categories['category']."</td>"; 
                            }
                    }
                }?>
                    <?php foreach($rows_specifications as $row_specifications){
                            if($row_specifications['id']===$row_items['specs_id']){
                                echo "<td>".$row_specifications['description']."</td>";
                                echo "<td>".$row_specifications['model']."</td>";
                                foreach($rows_brands as $row_brands){
                                    if($row_brands['id']===$row_specifications['brands_id']){
                                        echo "<td>".$row_brands['brand']."</td>"; 
                                    }
                                }
                    }}?>
                    <?php foreach($rows_item_info as $row_item_info){
                        if($row_item_info['id']===$row_items['item_info_id']){
                            echo "<td>".$row_item_info['ISBN']."</td>"; 
                            echo "<td>".$row_item_info['location']."</td>"; 
                            echo "<td>".$row_item_info['issued_to']."</td>"; 
                            echo "<td>".$row_item_info['date_acquired']."</td>"; 
                            echo "<td>".$row_item_info['PO_Ref_No']."</td>"; 
                            echo "<td>".$row_item_info['warranty']."</td>"; 
                            echo "<td>".$row_item_info['status']."</td>"; 
                            echo "<td>Status</td>"; 
                            echo "<td>button</td>";
                            echo "<td>button</td>";
                        }
                    }
                }?>
                  </tr>
                </tbody>
              </table>
            </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Statistics with subtitles-->
    </div>
</main>
<?php include_once('layouts/footer.php'); ?>