<?php
    
?>
<!-- Modal -->


<div class="modal fade" id="addItems" tabindex="-1" aria-labelledby="addItemsLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addItemsLabel">Items</h5>
      </div>
      <div class="card-body">
            <div class="table-responsive">
              <table class="table table-hover text-nowrap">
              <button type="button" class="btn btn-success btn-rounded btn-sm .align-items-center">Add</button>
                <thead>
                  <tr>
                    <th scope="col">Category</th>
                    <th scope="col">Description</th>
                    <th scope="col">Model</th>
                    <th scope="col">Brand</th>
                    <th scope="col">Serial No./ISBN</th>
                    <th scope="col">Location(Bldg/Flr)</th>
                    <th scope="col">Issued To</th>
                    <th scope="col">Date Acquired</th>
                    <th scope="col">Purchased Value</th>
                    <th scope="col">PO Ref No.</th>
                    <th scope="col">Warranty</th>
                    <th scope="col">Status/Remarks</th>
                    <th scope="col">Operation</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                  <?php include("functions/items/fetch_item_info.php");?>
                  <?php  ?>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
    </div>
  </div>
</div>