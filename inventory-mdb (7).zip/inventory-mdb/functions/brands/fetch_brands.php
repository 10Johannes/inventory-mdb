<?php 
    $query_brands ="SELECT * FROM brands";
    $result_brands = $conn->query($query_brands);
    if($result_brands->num_rows> 0){
      $rows_brands= mysqli_fetch_all($result_brands, MYSQLI_ASSOC);
    }
?>