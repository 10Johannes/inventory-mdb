
<?php 
    $query_specifications ="SELECT * FROM specifications";
    $result_specifications = $conn->query($query_specifications);
    if($result_specifications->num_rows> 0){
      $rows_specifications= mysqli_fetch_all($result_specifications, MYSQLI_ASSOC);
    }
?>