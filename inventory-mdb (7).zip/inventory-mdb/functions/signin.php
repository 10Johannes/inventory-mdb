<?php 
    require_once "../database/dbcon.php";
    if(isset($_POST['submit'])){      

// Get input from the login form
$username = $_POST['username'];
$password = $_POST['password'];

// Sanitize input to prevent SQL injection
$username = $conn->real_escape_string($username);
$password = $conn->real_escape_string($password);

// Hash the password (if using password hashing)
// $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

// Prepare SQL query
$sql = "SELECT * FROM credentials  WHERE username='$username' ";
// Execute query
$result = $conn->query($sql);

if ($result->num_rows === 1) {
    $row = $result->fetch_assoc();

    // Verify the password (if using password hashing)
    // if (password_verify($password, $row['password'])) {
    if ($password === $row['password']) {
        // Successful login
        session_start();
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['id'] = $row['id'];
        echo "<script>alert('Log in successfully');
        window.location.href='../admin.php';
        </script>";
        // header("Location: ../admin.php"); // Redirect to a secure page after successful login
        exit();
        //echo "Login successful. Welcome, $username!";
        //echo"<script>document.location='index.php';</script>";
    } else {
        echo "<script>window.location.href='../index.php?message=incorrect';</script>";
    }
} else {
    echo "<script>window.location.href='../index.php?message=incorrect';</script>";
}

    }
?>