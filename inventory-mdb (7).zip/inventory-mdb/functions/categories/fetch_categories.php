<?php 
    $query_categories ="SELECT * FROM categories";
    $result_categories = $conn->query($query_categories);
    if($result_categories->num_rows> 0){
      $rows_categories= mysqli_fetch_all($result_categories, MYSQLI_ASSOC);
    }
?>