<?php 
include ('../../database/dbcon.php');
if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $delete = mysqli_query($conn, "DELETE FROM categories WHERE id=$id");
    if($delete)
    echo "<script>alert(' Record Delete Successfully ');</script>";
    echo "<script>document.location='../../categories.php';</script>";
}

?>