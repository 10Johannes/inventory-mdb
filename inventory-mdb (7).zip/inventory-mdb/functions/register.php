<?php
    require_once "../database/dbcon.php";

    //if (!empty($_POST)){}
        if (isset($_POST['submit'])){
            $username=$_POST['username'];
            $password=$_POST['password'];

            $sql="INSERT INTO credentials(username, password) VALUE ('$username', '$password')";
            $sql1="SELECT * FROM credentials WHERE username='$username'";
            $result=mysqli_query($conn, $sql1);
            $present=mysqli_num_rows($result);
do{
   if(empty($username) || empty($password)){
    echo "<script>alert('All Fields Are REquired!!')</script>";
    break;
   } elseif($present>0){
    echo "<script>alert('Username already exists');</script>";
    break;
   }elseif($conn->query($sql) === TRUE){
    echo "<script>alert('Account Created');</script>";
   echo "<script>document.location='../index.php';</script>";
    break;
   }else{
    echo "<script>alert('Something Went Wrong!!');</script>";
    break;
   }
} while(false);
           
        }
    
?>