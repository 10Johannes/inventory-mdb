<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $categories_id = $_POST['categories_id'];
        $model = $_POST['model'];
        $brands_id = $_POST['brands_id'];
        $purchased_value = $_POST['purchased_value'];
        $description = $_POST['description'];
        $date_acquired = $_POST['date_acquired'];
        $warranty = $_POST['warranty'];
        $location = $_POST['location'];
        $issued_to = $_POST['issued_to'];
        $ISBN = $_POST['ISBN'];
        $PO_Ref_No = $_POST['PO_Ref_No'];
        $sql1 = "INSERT INTO specifications(model, brands_id, purchased_value, description) VALUES ('$model', '$brands_id', '$purchased_value', '$description')";
        $sql2 = "INSERT INTO item_info(ISBN, location, issued_to, date_acquired, PO_Ref_No, warranty) VALUES ('$ISBN', '$location', '$issued_to', '$date_acquired', '$PO_Ref_No', '$warranty')";
    do{
        if(($conn->query($sql1) && $conn->query($sql2)) === TRUE){
            $specs_last_id = $conn->insert_id;
            $info_last_id = $conn->insert_id;
            $sql3 = "INSERT INTO items(categories_id,specs_id,item_info_id) VALUES ('$categories_id','$specs_last_id','$info_last_id')";
            if($conn->query($sql3)===TRUE){
                echo "<script>alert('Item added successfully');
                window.location.href='../../items.php';
                </script>";
                break;
            }
        }else{
            echo "<script>alert('Something Went Wrong!!');</script>";
            break;
        }
        } while(false);
    }
?>