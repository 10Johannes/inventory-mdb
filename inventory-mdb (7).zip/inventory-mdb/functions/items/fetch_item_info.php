
<?php 
    $query_item_info ="SELECT * FROM item_info";
    $result_item_info = $conn->query($query_item_info);
    if($result_item_info->num_rows> 0){
      $rows_item_info= mysqli_fetch_all($result_item_info, MYSQLI_ASSOC);
    }
?>