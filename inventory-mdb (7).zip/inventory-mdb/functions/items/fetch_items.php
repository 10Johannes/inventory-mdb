
<?php 
    $rows_items = null;
    $query_items ="SELECT * FROM items";
    $result_items = $conn->query($query_items);
    if($result_items->num_rows> 0){
      $rows_items= mysqli_fetch_all($result_items, MYSQLI_ASSOC);
    } 
?>