<!-- Modal -->
<div class="modal fade" id="deletePrivileges<?php echo $row['id']?>" tabindex="-1" aria-labelledby="deletePrivilegesLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered" >
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deletePrivilegesLabel"> Are You Sure You Want To Delete?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <main class="form-modal">
            <form method="post" class="clearfix" action="functions/privileges/delete_privileges.php">
                <div class="modal-footer row justify-content-center">
                    <input type="hidden" name="id"  value="<?php echo $row['id'];?>">
                    <button class="btn btn-danger btn-md center" type="submit" id="delete-privilege-button" value="<?php echo $row['id'];?>" name="submit">Confirm</button>
                </div>
            </form>
        </main>
      </div>
    </div>
  </div>
</div>