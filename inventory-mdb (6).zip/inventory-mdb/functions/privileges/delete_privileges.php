<?php 
include ('../../database/dbcon.php');
if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $delete = mysqli_query($conn, "DELETE FROM privileges WHERE id=$id");
    if($delete)
    echo "<script>alert('Privilege deleted successfully!');</script>";
    echo "<script>document.location='../../privileges.php';</script>";
}

?>