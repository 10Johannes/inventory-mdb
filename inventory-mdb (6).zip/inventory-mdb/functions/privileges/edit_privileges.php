<?php
  require_once '../../database/dbcon.php';
 
  if(ISSET($_POST['submit'])){
    $id = $_POST['id'];
    $category = $_POST['privilege'];
    
 
    do{
        if($conn->query("UPDATE `privileges` SET `privilege_name` = '$privilege' WHERE `id` = '$id'") === TRUE){
            echo "<script>alert('Privilege updated successfully');
                window.location.href='../../privileges.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../privileges.php';
            </script>";
            break;
        }
        } while(false);
  }
?>