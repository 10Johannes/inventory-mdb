<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $privilege = $_POST['privilege'];
        $sql = "INSERT INTO privileges(privilege_name) VALUES ('$privilege')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Privilege added successfully');
                window.location.href='../../privileges.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../privileges.php';
            </script>";
            break;
        }
        } while(false);
    }
?>