<?php include_once('database/dbcon.php'); ?>
<?php include_once('layouts/header.php'); ?>
<header>
    <?php include_once('layouts/sidebar.php'); ?>
    <?php include_once('layouts/navbar.php'); ?>
</header>
<main style="margin-top: 58px">
    <div class="container pt-4">
    <!--Section: Statistics with subtitles-->
    <section>
        <div class="row">
          <div class="col-xl-3 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>Add Privileges</strong>
                </h5>
            </div>
              <div class="card-body">
                <form method="post" class="clearfix" action="functions/privileges/add_privileges.php">
                    <div class="mb-3">
                        <input type="text" class="form-control" placeholder="Privilege Name" aria-label="Privilege Name" aria-describedby="add-privilege-button" name="privilege" pattern="[a-zA-Z]{}" required>
                        <input type="number" class="form-control" placeholder="Privilege Level" aria-label="Privilege Level" aria-describedby="add-privilege-button" name="privilege" pattern="[0-9]{}" required>
                        <button class="btn btn-success" type="submit" id="add-privilege-button" name="submit">Add</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-xl-9 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>All Privileges</strong>
                </h5>
            </div>
              <div class="card-body">
              <div class="table-responsive">
              <table class="table table-hover text-nowrap">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Privilege Name</th>
                        <th scope="col">Privilege Level</th>
                        <th scope="col">Operations</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <!-- Fetch Privileges -->
                        <?php
                        $sql = "SELECT * FROM privileges";
                        $result = $conn->query($sql);
                        if(!$result){
                            die("Invalid query" .$connection_error);
                        }else{
                            while ($row = $result->fetch_assoc()) {
                        ?>
                        <!-- Fetch Privileges -->
                    <?php echo "<td>".$row['id']."</td>"; ?>
                    <?php echo "<td>".$row['privilege_name']."</td>"; ?>
                    <?php echo "<td>".$row['privilege_level']."</td>"; ?>
                        <td>
                            <button  class="btn btn-danger btn-sm" aria-hidden="true"  data-bs-toggle="modal" data-bs-target="#deletePrivileges<?php echo $row['id']?>">DELETE</button>
                            <button class="btn btn-success btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#editPrivileges<?php echo $row['id']?>" >EDIT</button>
                        </td>
                    </tr>
                    
                    <?php include("forms/privileges/edit_privileges.php");
                          include("forms/privileges/delete_privileges.php");
                            }} ?>
                </tbody>
              </table>
            </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Statistics with subtitles-->
    </div>
</main>
<?php include_once('layouts/footer.php'); ?>