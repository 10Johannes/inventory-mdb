<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit1'])){
        $category = $_POST['category'];
        $sql = "INSERT INTO categories(category) VALUES ('$category')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Item added successfully');</script>";
            echo "<script>document.location='../../categories.php';</script>";
            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');</script>";
            break;
        }
        } while(false);
    }
?>