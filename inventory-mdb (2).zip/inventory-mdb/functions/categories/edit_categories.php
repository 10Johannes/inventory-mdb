<?php 
    include("../../database/dbcon.php");
    if(isset($_POST['submit'])){
        $category=$_POST['category'];
        $id=$_POST['id'];
    do{
        if(empty($_POST['category'])){
            echo "<script>alert('Enter a category');</script>";
        } elseif ($conn->query("UPDATE categories SET category='$category' WHERE id='$id'")===TRUE){
            echo "<script>alert('Field updated succesfully');</script>";
            echo "<script>document.location='../../categories.php';</script>";
        } else {
            echo "<script>alert('Something went wrong');</script>";
        }break;
    }while(false);
}
?>