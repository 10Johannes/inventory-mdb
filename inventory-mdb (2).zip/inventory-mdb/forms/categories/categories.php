

<div class="modal fade" id="staticBackdrop" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Update</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <?php
require_once "database/dbcon.php";
$query = mysqli_query($conn, "SELECT * FROM categories");
while($fetch = mysqli_fetch_array($query)){
?>


      <form method="post" class="clearfix" action="functions/categories/edit_categories.php">
                    <div class="form-floating">
                      <input type="text" class="form-control"  id="floatingInput" value="<?php echo $fetch['category']?>" name="category" required>
                      <label for="floatingInput">Category Name</label>
                      <input type="hidden" value="<?php echo $fetch['id']?>" name="id">
                    </div>
                    <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-danger" name="submit">Update</button>
      </div>
                 </form>
                 <?php
}
                 ?>

      </div>
    </div>
  </div>
</div>

