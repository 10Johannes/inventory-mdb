<?php include("layouts/header.php"); ?>


  <!--Main layout-->
  <main style="margin-top: 58px">
    <div class="container pt-4">
      <!--Section: Statistics with subtitles-->
      <section>
        <div class="row">
          <div class="col-xl-3 col-md-12 mb-4">
            <div class="card">
            <div class="card-header py-3">
                <h5 class="mb-0 text-center"><strong>Add Categories</strong></h5>
            </div>
              <div class="card-body">
                <div class="d-flex justify-content-between p-md-1">
                  <form method="post" class="clearfix" action="functions/categories/add_categories.php">
                  <div class="input-group">
                    <input type="text" class="form-control"  id="floatingInput" placeholder="Category Name" name="category" required aria-label="Category Name" aria-describedby="button-addon2">
                    <button class="btn btn-success" type="submit" name="submit1">Add</button>
                  </div>
                 </form>
                </div>
              </div>
            </div>
          </div>
          <div class="col-xl-9 col-md-12 mb-4">
            <div class="card">
              <div class="card-header py-3">
                <h5 class="mb-0 text-center"><strong>Categories</strong></h5>
              </div>
              <div class="card-body">
                <div class="d-flex justify-content-between p-md-1">
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-hover text-nowrap">
                      <thead>
                        <tr>
                          <th scope="col">#</th>
                          <th scope="col">Category Name</th>
                          <th scope="col">Operations</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <!-- Fetch Categories -->
                          <?php
                            $sql = "SELECT * FROM categories";
                            $result = $conn->query($sql);
                            if(!$result){
                              die("Invalid query" .$connection_error);
                            }else{
                              while ($row = $result->fetch_assoc()) {
                          ?>
                          <!-- Fetch Categories -->
                        <?php echo "<td>".$row['id']."</td>"; ?>
                        <?php echo "<td>".$row['category']."</td>"; ?>
                          <td>
                          <button  class="btn btn-danger btn-sm" aria-hidden="true"  data-bs-toggle="modal" data-bs-target="#exampleModal1">DELETE</button>
                        <button class="btn btn-success btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#staticBackdrop" name="submit">EDIT</button>
                          <?php
                            include("functions/categories/delete_categories.php");
                            include("forms/categories/categories.php");
                          ?>
                          </td>
                        </tr>
                        <?php }} ?>
                      </tbody>
                    </table>
                  </div>
                </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Statistics with subtitles-->
      </div>
  </main>
  <!--Footer-->
  <?php include("layouts/footer.php"); ?>
