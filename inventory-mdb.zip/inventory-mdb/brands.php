<?php include_once('database/dbcon.php'); ?>
<?php include_once('functions/fetch.php'); ?>
<?php 
$all_brands = find_all('brands');
?>
<?php include_once('layouts/header.php'); ?>
<header>
    <?php include_once('layouts/sidebar.php'); ?>
    <?php include_once('layouts/navbar.php'); ?>
</header>
<main style="margin-top: 58px">
    <div class="container pt-4">
    <!--Section: Statistics with subtitles-->
    <section>
        <div class="row">
          <div class="col-xl-3 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>Add Brands</strong>
                </h5>
            </div>
              <div class="card-body">
                <form method="post" class="clearfix" action="functions/brands/add_brands.php">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Brand Name" aria-label="Brand Name" aria-describedby="add-brand-button" name="brand" pattern="[a-zA-Z]{}" required>
                        <button class="btn btn-success" type="submit" id="add-brand-button" name="submit">Add</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-xl-9 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>All Brands</strong>
                </h5>
            </div>
              <div class="card-body">
              <div class="table-responsive">
              <table class="table table-hover text-nowrap">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Brand Name</th>
                        <th scope="col">Operations</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                  if($all_brands !== null):
                    foreach ($all_brands as $brand):?>
                    <tr>
                    <td><?php echo $brand['id'];?></td>
                    <td><?php echo $brand['brand'];?></td>
                        <td>
                            <button  class="btn btn-danger btn-sm" aria-hidden="true"  data-bs-toggle="modal" data-bs-target="#deleteBrands<?php echo $brand['id'];?>">DELETE</button>
                            <button class="btn btn-success btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#editBrands<?php echo $brand['id'];?>" >EDIT</button>
                        </td>
                    </tr>
                    
                    <?php include("forms/brands/edit_brands.php");
                          include("forms/brands/delete_brands.php");
                            ?>
                <?php endforeach;
                  endif; ?>
                </tbody>
              </table>
            </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Statistics with subtitles-->
    </div>
</main>
<?php include_once('layouts/footer.php'); ?>