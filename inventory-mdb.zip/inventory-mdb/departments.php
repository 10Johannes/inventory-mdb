<?php include_once('database/dbcon.php'); ?>
<?php include_once('functions/fetch.php'); ?>
<?php 
$all_departments = find_all('departments');
?>
<?php include_once('layouts/header.php'); ?>
<header>
    <?php include_once('layouts/sidebar.php'); ?>
    <?php include_once('layouts/navbar.php'); ?>
</header>
<main style="margin-top: 58px">
    <div class="container pt-4">
    <!--Section: Statistics with subtitles-->
    <section>
        <div class="row">
          <div class="col-xl-3 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>Add Departments</strong>
                </h5>
            </div>
              <div class="card-body">
                <form method="post" class="clearfix" action="functions/departments/add_departments.php">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Department Name" aria-label="Department Name" aria-describedby="add-department-button" name="department" pattern="[a-zA-Z]{}" required>
                        <button class="btn btn-success" type="submit" id="add-department-button" name="submit">Add</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-xl-9 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>All Department</strong>
                </h5>
            </div>
              <div class="card-body">
              <div class="table-responsive">
              <table class="table table-bordered">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Department Name</th>
                        <th scope="col">Operations</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                  if($all_departments !== null):
                    foreach ($all_departments as $dept):?>
                    <tr>
                    <td><?php echo $dept['id'];?></td>
                    <td><?php echo $dept['department'];?></td>
                        <td>
                            <button  class="btn btn-danger btn-sm" aria-hidden="true"  data-bs-toggle="modal" data-bs-target="#deleteDepartments<?php echo $dept['id'];?>">DELETE</button>
                            <button class="btn btn-success btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#editDepartments<?php echo $dept['id'];?>" >EDIT</button>
                        </td>
                    </tr>
                    
                    <?php include("forms/departments/edit_departments.php");
                          include("forms/departments/delete_departments.php");
                           endforeach;
                            ?>
                <?php 
                  endif; ?>
                </tbody>
              </table>
            </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Statistics with subtitles-->
    </div>
</main>
<?php include_once('layouts/footer.php'); ?>