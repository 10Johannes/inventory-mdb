<?php
  require_once '../../database/dbcon.php';
 
  if(ISSET($_POST['submit'])){
    $id = $_POST['id'];
    $category_id = $_POST['category_id'];
    $model = $_POST['model'];
    $brand_id = $_POST['brand_id'];
    $purchased_value = $_POST['purchased_value'];
    $description = $_POST['description'];
    $warranty = $_POST['warranty'];
    $date_acquired = $_POST['date_acquired'];
    $ISBN = $_POST['ISBN'];
    $PO_Ref_No = $_POST['PO_Ref_No'];
    $location = $_POST['location'];
    $issued_to = $_POST['issued_to'];  
    $sql = "UPDATE `items` SET `category_id`='$category_id',`model`='$model',`brand_id`='$brand_id',`purchased_value`='$purchased_value',`description`='$description',`warranty`='$warranty',`date_acquired`='$date_acquired',`ISBN`='$ISBN',`PO_Ref_No`='$PO_Ref_No',`location`='$location',`issued_to`='$issued_to' WHERE `id`=$id";
    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Item updated successfully');
                window.location.href='../../items.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../items.php';
            </script>";
            break;
        }
        } while(false);
  }
?>