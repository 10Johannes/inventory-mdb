<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $category_id = $_POST['category_id'];
        $model = $_POST['model'];
        $brand_id = $_POST['brand_id'];
        $purchased_value = $_POST['purchased_value'];
        $description = $_POST['description'];
        $warranty = $_POST['warranty'];
        $date_acquired = $_POST['date_acquired'];
        $ISBN = $_POST['ISBN'];
        $PO_Ref_No = $_POST['PO_Ref_No'];
        $location = $_POST['location'];
        $issued_to = $_POST['issued_to'];
        $sql = "INSERT INTO items(category_id, model, brand_id, purchased_value, description, warranty, date_acquired, ISBN, PO_Ref_No, location, issued_to) VALUES ('$category_id', '$model', '$brand_id', '$purchased_value', '$description', '$warranty', '$date_acquired', '$ISBN', '$PO_Ref_No', '$location', '$issued_to')";
    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Item added successfully');
            window.location.href='../../items.php';
            </script>";
        }else{
            echo "<script>alert('Something went wrong!!');</script>";
            break;
        }
        } while(false);
    }
?>