<?php
  require_once '../../database/dbcon.php';
 
  if(ISSET($_POST['submit'])){
    $id = $_POST['id'];
    $department = $_POST['department'];
    
 
    do{
        if($conn->query("UPDATE `departments` SET `department` = '$department' WHERE `id` = '$id'") === TRUE){
            echo "<script>alert('Department updated successfully');
                window.location.href='../../departments.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something went wrong!');
            window.location.href='../../departments.php';
            </script>";
            break;
        }
        } while(false);
  }
?>