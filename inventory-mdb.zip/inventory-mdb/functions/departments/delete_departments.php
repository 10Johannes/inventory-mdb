<?php 
include ('../../database/dbcon.php');
if(isset($_POST['submit'])){
    $id=$_POST['id'];
    $delete = mysqli_query($conn, "DELETE FROM departments WHERE id=$id");
    if($delete){
    echo "<script>alert('Record delete successfully');</script>";
    echo "<script>document.location='../../departments.php';</script>";
    }
}

?>