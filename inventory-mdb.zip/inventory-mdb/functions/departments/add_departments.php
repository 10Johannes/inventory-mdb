<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $department = strtoupper($_POST['department']);
        $sql = "REPLACE INTO departments(department) VALUES ('$department')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Department added successfully');
                window.location.href='../../departments.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something went wrong!');
            window.location.href='../../departments.php';
            </script>";
            break;
        }
        } while(false);
    }
?>