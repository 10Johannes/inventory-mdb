<?php
    require_once "../database/dbcon.php";

    //if (!empty($_POST)){}
        if (isset($_POST['submit'])){
            $firstname=$_POST['firstname'];
            $lastname=$_POST['lastname'];
            $username=$_POST['username'];
            $password=$_POST['password'];
            $department=(int)$_POST['department'];
            $privilege=($department===1)? 1 : 2;
            $sql="INSERT INTO users(username, password, privilege_id, department_id, firstname, lastname) VALUE ('$username', '$password', $privilege, $department, '$firstname', '$lastname')";
            $sql1="SELECT * FROM users WHERE username='$username'";
            $result=mysqli_query($conn, $sql1);
            $present=mysqli_num_rows($result);
do{
   if(empty($username) || empty($password)){
    echo "<script>alert('All fields are required!')</script>";
    break;
   } elseif($present>0){
    echo "<script>alert('Username already exists!');</script>";
    break;
   }elseif($conn->query($sql) === TRUE){
    echo "<script>alert('Account Created!');</script>";
   echo "<script>document.location='../index.php';</script>";
    break;
   }else{
    echo "<script>alert('Something went wrong!');</script>";
    break;
   }
} while(false);
           
        }
    
?>