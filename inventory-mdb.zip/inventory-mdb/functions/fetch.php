<?php 
  require_once('database/dbcon.php');

    function find_all($table) {
      global $conn;
      $query ="SELECT * FROM ".$table;
      $result = $conn->query($query);
      if($result->num_rows > 0){
        $rows = mysqli_fetch_all($result, MYSQLI_ASSOC);
      } else {
        $rows = null;
      }
      return $rows;
     }
?>