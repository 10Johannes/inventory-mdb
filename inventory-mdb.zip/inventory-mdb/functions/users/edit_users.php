<?php
require_once "../../database/dbcon.php";

//if (!empty($_POST)){}
if (isset($_POST['submit'])) {
    $id = $_POST['id'];
    $firstname = $_POST['firstname'];
    $lastname = $_POST['lastname'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $department = $_POST['department'];
    $privilege = $_POST['privilege'];
    $sql = "UPDATE users SET username='$username', password='$password', privilege_id='$privilege', department_id='$department', firstname='$firstname', lastname='$lastname' WHERE id=$id";
    $sql1 = "SELECT * FROM users WHERE username='$username' AND NOT id=$id";
    $result = mysqli_query($conn, $sql1);
    $present = mysqli_num_rows($result);
    do {
        if (empty($username) || empty($password)) {
            echo "<script>alert('All fields are required!')</script>";
            break;
        } elseif ($present > 0) {
            echo "<script>alert('Username already exists!');</script>";
            break;
        } elseif ($conn->query($sql) === TRUE) {
            echo "<script>alert('Account Updated!');</script>";
            echo "<script>document.location='../../users.php';</script>";
            break;
        } else {
            echo "<script>alert('Something went wrong!');</script>";
            break;
        }
    } while (false);
}
