<?php
  require_once '../../database/dbcon.php';
 
  if(ISSET($_POST['submit'])){
    $id = $_POST['id'];
    $privilege = $_POST['privilege'];
    $level = $_POST['level'];
    $sql = "UPDATE `privileges` SET `privilege` = '$privilege', `level` = '$level' WHERE `id` = '$id'";
 
    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Privilege updated successfully');
                window.location.href='../../privileges.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../privileges.php';
            </script>";
            break;
        }
        } while(false);
  }
?>