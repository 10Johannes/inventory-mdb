<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $item_id = $_POST['item_id'];
        $remark = $_POST['remark'];
        $remark_date = $_POST['remark_date'];
        $sql = "INSERT INTO remarks(item_id, remark, remark_date) VALUES ('$item_id', '$remark', '$remark_date')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Remark added successfully');
                window.location.href='../../remarks.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../remarks.php';
            </script>";
            break;
        }
        } while(false);
    }
?>