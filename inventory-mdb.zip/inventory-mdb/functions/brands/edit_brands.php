<?php
  require_once '../../database/dbcon.php';
 
  if(ISSET($_POST['submit'])){
    $id = $_POST['id'];
    $brand = $_POST['brand'];
    
 
    do{
        if($conn->query("UPDATE `brands` SET `brand` = '$brand' WHERE `id` = '$id'") === TRUE){
            echo "<script>alert('Brand updated successfully');
                window.location.href='../../brands.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../brands.php';
            </script>";
            break;
        }
        } while(false);
  }
?>