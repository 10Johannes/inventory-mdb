<?php
  require_once '../../database/dbcon.php';
 
  if(ISSET($_POST['submit'])){
    $id = $_POST['id'];
    $category = $_POST['category'];
    
 
    do{
        if($conn->query("UPDATE `categories` SET `category` = '$category' WHERE `id` = '$id'") === TRUE){
            echo "<script>alert('Item updated successfully');
                window.location.href='../../categories.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../categories.php';
            </script>";
            break;
        }
        } while(false);
  }
?>