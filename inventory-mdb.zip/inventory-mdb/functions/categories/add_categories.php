<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $category = $_POST['category'];
        $sql = "INSERT INTO categories(name) VALUES ('$category')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Item added successfully');</script>";
            header("Location: ../../admin.php");
            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');</script>";
            break;
        }
        } while(false);
    }
?>