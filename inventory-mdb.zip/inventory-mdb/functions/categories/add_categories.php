<?php 
    require_once("../../database/dbcon.php");
    if (isset($_POST['submit'])){
        $category = strtoupper($_POST['category']);
        $sql = "REPLACE INTO categories(category) VALUES ('$category')";

    do{
        if($conn->query($sql) === TRUE){
            echo "<script>alert('Category added successfully');
                window.location.href='../../categories.php';
            </script>";

            break;
        }else{
            echo "<script>alert('Something Went Wrong!!');
            window.location.href='../../categories.php';
            </script>";
            break;
        }
        } while(false);
    }
?>