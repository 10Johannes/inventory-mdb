<!-- Modal -->
<div class="modal fade" id="editPrivileges<?php echo $privilege['id'] ?>" tabindex="-1" aria-labelledby="editPrivilegesLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editPrivilegesLabel">Privileges</h5>
      </div>
      <div class="card-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/Privileges/edit_privileges.php">
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingPrivilege" placeholder="Privilege Name" value="<?php echo $privilege['privilege']; ?>" name="privilege" pattern="[a-zA-Z]{}" required>
              <label for="floatingPrivilege">Privilege Name</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="number" class="form-control" id="floatingLevel" placeholder="Privilege Level" value="<?php echo $privilege['level']; ?>" name="level" pattern="[0-9]{}" required>
              <label for="floatingLevel">Privilege Level</label>
            </div>
            <br>
            <input type="hidden" value="<?php echo $privilege['id']; ?>" name="id">
            <button class="btn btn-success" type="submit" id="edit-privilege-button" value="<?php echo $privilege['privilege']; ?>" name="submit">Update</button>
      </div>
      </form>
      </main>
    </div>

  </div>
</div>
</div>