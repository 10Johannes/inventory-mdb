<!-- Modal -->

<div class="modal fade" id="addSpecifications" tabindex="-1" aria-labelledby="addSpecificationsLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addSpecificationsLabel">Specifications</h5>
      </div>
      <div class="modal-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/specifications/add_specification.php">
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Description" name="description" required>
            <label for="floatingInput">Description</label>
          </div>
          <br>
             
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Model" name="model" required>
            <label for="floatingInput">Model</label>
          </div>
          <br>
          
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Brand" name="brand" required>
            <label for="floatingInput">Brand</label>
          </div>
          <br>
         
          <button class="w-50 btn btn-sm btn-success center" type="submit" name="submit">Add Specifications</button>
          </form>
        </main>
      </div>
    </div>
  </div>
</div>