<!-- Modal -->
<div class="modal fade" id="deleteDepartments<?php echo $dept['id']?>" tabindex="-1" aria-labelledby="deleteDepartmentsLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered" >
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteDepartmentsLabel"> Are You Sure You Want To Delete?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <main class="form-modal">
            <form method="post" class="clearfix" action="functions/departments/delete_departments.php">
                <div class="modal-footer row justify-content-center">
                    <input type="hidden" name="id"  value="<?php echo $dept['id'];?>">
                    <button class="btn btn-danger btn-md center" type="submit" id="delete-department-button" value="<?php echo $dept['id'];?>" name="submit">Confirm</button>
                </div>
            </form>
        </main>
      </div>
    </div>
  </div>
</div>