<!-- Modal -->
<div class="modal fade" id="editDepartments<?php echo $dept['id']?>" tabindex="-1" aria-labelledby="editDepartmentsLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editDepartmentsLabel">Departments</h5>
      </div>
      <div class="modal-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/departments/edit_departments.php">
              <div class="input-group mb-3">
                  <input type="text" class="form-control" placeholder="Department Name" aria-label="Department Name" aria-describedby="edit-department-button" value="<?php echo $dept['department'];?>" name="department" pattern="[a-zA-Z]{}" required>
                  <input type="hidden"  value="<?php echo $dept['id'];?>" name="id">
                  <button class="btn btn-success" type="submit" id="edit-department-button" value="<?php echo $dept['department'];?>" name="submit">Update</button>
              </div>
          </form>
        </main>
      </div>

    </div>
  </div>
</div>