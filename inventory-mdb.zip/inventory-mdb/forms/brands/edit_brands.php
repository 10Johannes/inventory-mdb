<!-- Modal -->
<div class="modal fade" id="editBrands<?php echo $brand['id']?>" tabindex="-1" aria-labelledby="editBrandsLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editBrandsLabel">Brands</h5>
      </div>
      <div class="modal-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/brands/edit_brands.php">
              <div class="input-group mb-3">
                  <input type="text" class="form-control" placeholder="Brand Name" aria-label="Brand Name" aria-describedby="edit-brand-button" value="<?php echo $brand['brand'];?>" name="brand" pattern="[a-zA-Z]{}" required>
                  <input type="hidden"  value="<?php echo $brand['id'];?>" name="id">
                  <button class="btn btn-success" type="submit" id="edit-brand-button" value="<?php echo $brand['brand'];?>" name="submit">Update</button>
              </div>
          </form>
        </main>
      </div>

    </div>
  </div>
</div>