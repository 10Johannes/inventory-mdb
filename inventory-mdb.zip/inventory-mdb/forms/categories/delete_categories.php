<!-- Modal -->
<div class="modal fade" id="deleteCategories<?php echo $cat['id']?>" tabindex="-1" aria-labelledby="deleteCategoriesLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered" >
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteCategoriesLabel"> Are You Sure You Want To Delete?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <main class="form-modal">
            <form method="post" class="clearfix" action="functions/categories/delete_categories.php">
                <div class="modal-footer row justify-content-center">
                    <input type="hidden" name="id"  value="<?php echo $cat['id'];?>">
                    <button class="btn btn-danger btn-md center" type="submit" id="delete-category-button" value="<?php echo $cat['id'];?>" name="submit">Confirm</button>
                </div>
            </form>
        </main>
      </div>
    </div>
  </div>
</div>