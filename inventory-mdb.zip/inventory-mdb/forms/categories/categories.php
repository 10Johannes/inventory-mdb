<!-- Modal -->

<div class="modal fade" id="addCategories" tabindex="-1" aria-labelledby="addCategoriesLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addCategoriesLabel">Categories</h5>
      </div>
      <div class="modal-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/categories/add_categories.php">
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Category Name" name="category" required>
            <label for="floatingInput">Category Name</label>
          </div>
          <br>
          <button class="w-50 btn btn-sm btn-success center" type="submit" name="submit">Add Category</button>
          </form>
        </main>
      </div>
    </div>
  </div>
</div>