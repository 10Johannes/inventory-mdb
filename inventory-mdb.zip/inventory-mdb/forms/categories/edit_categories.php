<!-- Modal -->
<div class="modal fade" id="editCategories<?php echo $cat['id']?>" tabindex="-1" aria-labelledby="editCategoriesLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editCategoriesLabel">Categories</h5>
      </div>
      <div class="modal-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/categories/edit_categories.php">
              <div class="input-group mb-3">
                  <input type="text" class="form-control" placeholder="Category Name" aria-label="Category Name" aria-describedby="edit-category-button" value="<?php echo $cat['category'];?>" name="category" pattern="[a-zA-Z]{}" required>
                  <input type="hidden"  value="<?php echo $cat['id'];?>" name="id">
                  <button class="btn btn-success" type="submit" id="edit-category-button" value="<?php echo $cat['category'];?>" name="submit">Update</button>
              </div>
          </form>
        </main>
      </div>

    </div>
  </div>
</div>