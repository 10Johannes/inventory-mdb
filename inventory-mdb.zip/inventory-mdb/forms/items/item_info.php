<!-- Modal -->

<div class="modal fade" id="addItemInfos" tabindex="-1" aria-labelledby="addItemInfosLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addItemInfosLabel">Item Infos</h5>
      </div>
      <div class="modal-body">
        
      <main class="form-modal">
          <form method="post" class="clearfix" action="forms/items/add_item_info.php">
          
          
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Serial No./ISBN" name="ISBN" required>
            <label for="floatingInput">Serial No./ISBN:</label>
          </div>
          <br>
             
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Location(Bldg/Flr)" name="location" required>
            <label for="floatingInput">Location(Bldg/Flr):</label>
          </div>
          <br>
          
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Issued To" name="issued_to" required>
            <label for="floatingInput">Issued To:</label>
          </div>
          <br>

          <div class="form-floating">
            <input type="datetime-local" class="form-control" id="floatingInput" placeholder="Date Acquired" name="date_acquired" required>
            <label for="floatingInput">Date Acquired</label>
          </div>
          <br>
             
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Purchased Value" name="purchased_value" required>
            <label for="floatingInput">Purchased Value</label>
          </div>
          <br>
          
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="PO Ref No." name="PO_Ref_No" required>
            <label for="floatingInput">PO Ref No.</label>
          </div>
          <br>

          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Warranty" name="warranty" required>
            <label for="floatingInput">Warranty</label>
          </div>
          <br>
          
          <div class="form-floating">
            <input type="text" class="form-control" id="floatingInput" placeholder="Status/Remarks" name="status" required>
            <label for="floatingInput">Status/Remarks</label>
          </div>
          <br>
         
          <button class="w-50 btn btn-sm btn-success center" type="submit" name="submit1">Add Specifications</button>
          </form>

        </main>
      </div>
    </div>
  </div>
</div>