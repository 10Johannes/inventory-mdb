<!-- Modal -->
<div class="modal fade" id="editItems<?php echo $item['id'] ?>" tabindex="-1" aria-labelledby="editItemsLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editItemsLabel">Items</h5>
      </div>
      <div class="card-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/items/edit_items.php">
            <div class="form-floating">
              <div class="input-group">
                <div class="input-group-prepend">
                  <label class="input-group-text" for="inputGroupSelectCategories">Category</label>
                </div>
                <select class="custom-select form-control" id="inputGroupSelectCategories" name="category_id">
                  <option>Select Category...</option>
                  <?php
                  if ($all_categories !== null) {
                    foreach ($all_categories as $cat) { ?>
                      <option value="<?php echo $cat['id'] ?>" <?php echo ($cat['id']===$item['category_id'])? 'selected': '' ?>><?php echo $cat['category'] ?></option>
                  <?php 
                    }
                  } ?>
                </select>
              </div>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingModel" placeholder="Model" name="model" value="<?php echo $item['model'] ?>">
              <label for="floatingModel">Model</label>
            </div>
            <br>
            <div class="form-floating">
              <div class="input-group">
                <div class="input-group-prepend">
                  <label class="input-group-text" for="inputGroupSelectBrands">Brands</label>
                </div>
                <select class="custom-select form-control" id="inputGroupSelectBrands" name="brand_id">
                  <option>Select Brand...</option>
                  <?php
                  if ($all_brands !== null) {
                    foreach ($all_brands as $brand) { ?>
                      <option value="<?php echo $brand['id'] ?>" <?php echo ($brand['id']===$item['brand_id'])? 'selected': '' ?>><?php echo $brand['brand'] ?></option>
                  <?php 
                    }
                  } ?>
                </select>
              </div>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingPurchasedValue" placeholder="Purchased Value" name="purchased_value" value="<?php echo $item['purchased_value'] ?>">
              <label for="floatingPurchasedValue">Purchased Value</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingDescription" placeholder="Description" name="description" value="<?php echo $item['description'] ?>">
              <label for="floatingPassword">Description</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingWarranty" placeholder="Warranty" name="warranty" value="<?php echo $item['warranty'] ?>">
              <label for="floatingWarranty">Warranty</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="datetime-local" class="form-control" id="floatingDateAcquired" placeholder="Date Acquired" name="date_acquired" value="<?php echo $item['date_acquired'] ?>">
              <label for="floatingDateAcquired">Date Acquired</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingISBN" placeholder="ISBN" name="ISBN" value="<?php echo $item['ISBN'] ?>">
              <label for="floatingISBN">Serial No./ISBN</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingPORefNo" placeholder="PO Ref No." name="PO_Ref_No" value="<?php echo $item['PO_Ref_No'] ?>">
              <label for="floatingPORefNo">PO Ref No.</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingLocation" placeholder="Location" name="location" value="<?php echo $item['location'] ?>">
              <label for="floatingLocation">Location(Bldg/Flr)</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingIssuedTo" placeholder="Issued To" name="issued_to" value="<?php echo $item['issued_to'] ?>">
              <label for="floatingIssuedTo">Issued To</label>
            </div>
            <input type="hidden"  value="<?php echo $item['id'];?>" name="id">
            <br>
            <button class="w-50 btn btn-md btn-success center" type="submit" name="submit">Update</button>
          </form>
        </main>
      </div>
    </div>
  </div>
</div>