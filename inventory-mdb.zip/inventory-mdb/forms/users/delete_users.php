<!-- Modal -->
<div class="modal fade" id="deleteUsers<?php echo $user['id']?>" tabindex="-1" aria-labelledby="deleteUsersLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
  <div class="modal-dialog modal-sm  modal-dialog-centered" >
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="deleteUsersLabel"> Are You Sure You Want To Delete?</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <main class="form-modal">
            <form method="post" class="clearfix" action="functions/users/delete_users.php">
                <div class="modal-footer row justify-content-center">
                    <input type="hidden" name="id"  value="<?php echo $user['id'];?>">
                    <button class="btn btn-danger btn-md center" type="submit" id="delete-user-button" value="<?php echo $user['id'];?>" name="submit">Confirm</button>
                </div>
            </form>
        </main>
      </div>
    </div>
  </div>
</div>