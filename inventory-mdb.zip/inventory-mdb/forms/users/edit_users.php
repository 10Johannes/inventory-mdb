<!-- Modal -->
<div class="modal fade" id="editUsers<?php echo $user['id'] ?>" tabindex="-1" aria-labelledby="editUsersLabel" aria-hidden="true" data-mdb-backdrop="true" data-mdb-keyboard="true">
    <div class="modal-dialog modal-sm  modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="editUsersLabel">Users</h5>
            </div>
            <div class="modal-body">
                <main class="form-modal">
                    <form method="post" class="clearfix" action="functions/users/edit_users.php">
                        <div class="form-floating">
                            <input type="text" class="form-control" id="floatingFirstName" placeholder="First Name" name="firstname" value="<?php echo $user['firstname'] ?>" required>
                            <label for="floatingFirstName">First Name</label>
                        </div>
                        <br>
                        <div class="form-floating">
                            <input type="text" class="form-control" id="floatingLastName" placeholder="Last Name" name="lastname" value="<?php echo $user['lastname'] ?>" required>
                            <label for="floatingLastName">Last Name</label>
                        </div>
                        <br>
                        <div class="form-floating">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="inputGroupSelectDepartments">Departments</label>
                                </div>
                                <select class="custom-select form-control" id="inputGroupSelectDepartments" name="department">
                                    <option>Select Departments...</option>
                                    <?php
                                    if ($all_departments !== null) {
                                        foreach ($all_departments as $dept) {
                                            if ($dept['id'] === $user['department_id']) { ?>
                                                <option value="<?php echo  $user['department_id'] ?>" <?php echo 'selected' ?>><?php echo  $dept['department'] ?></option>
                                    <?php   } else {
                                                echo "<option value='" . $dept['id'] . "' >" . $dept['department'] . "</option>";
                                            }
                                        }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="form-floating">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <label class="input-group-text" for="inputGroupSelectPrivileges">Privileges</label>
                                </div>
                                <select class="custom-select form-control" id="inputGroupSelectPrivileges" name="privilege">
                                    <option>Select Privileges...</option>
                                    <?php
                                    if ($all_privileges !== null) {
                                        foreach ($all_privileges as $privilege) {
                                            if ($privilege['id'] === $user['privilege_id']) { ?>
                                                <option value="<?php echo  $user['privilege_id'] ?>" <?php echo 'selected' ?>><?php echo  $privilege['privilege'] ?></option>
                                    <?php   } else {
                                                echo "<option value='" . $privilege['id'] . "' >" . $privilege['privilege'] . "</option>";
                                            }
                                        }
                                    } ?>
                                </select>
                            </div>
                        </div>
                        <br>
                        <div class="form-floating">
                            <input type="username" class="form-control" id="floatingInput" placeholder="Username" name="username" value="<?php echo $user['username'] ?>" required>
                            <label for="floatingInput">Username</label>
                        </div>
                        <br>
                        <div class="form-floating">
                            <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password" value="<?php echo $user['password'] ?>" required>
                            <label for="floatingPassword">Password</label>
                        </div>
                        <input type="hidden" value="<?php echo $user['id'] ?>" name="id">
                        <br>
                        <button class="w-50 btn btn-lg btn-success center" type="submit" name="submit">Update</button>
                    </form>
                </main>
            </div>

        </div>
    </div>
</div>