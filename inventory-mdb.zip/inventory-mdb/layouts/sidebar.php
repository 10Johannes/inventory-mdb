    <!-- Sidebar -->
    <nav id="sidebarMenu" class="collapse d-lg-block sidebar collapse bg-white">
      <div class="position-sticky">
        <div class="list-group list-group-flush mx-3 mt-4">
          <a href="admin.php" class="list-group-item list-group-item-action py-2 ripple" aria-current="true">
            <i class="fas fa-tachometer-alt fa-fw me-3"></i><span>Main Dashboard</span>
          </a>
          <a href="users.php" class="list-group-item list-group-item-action py-2 ripple"><i
              class="fas fa-users fa-fw me-3"></i><span>Users</span></a>
          <a href="privileges.php" class="list-group-item list-group-item-action py-2 ripple"><i 
              class="fas fa-universal-access fa-fw me-3"></i><span>Privileges</span></a>
          <a href="departments.php" class="list-group-item list-group-item-action py-2 ripple"><i 
              class="fas fa-building fa-fw me-3"></i><span>Departments</span></a>
          <a href="categories.php" class="list-group-item list-group-item-action py-2 ripple"><i
              class="fas fa-border-all fa-fw me-3"></i><span>Categories</span></a>
          <a href="brands.php" class="list-group-item list-group-item-action py-2 ripple"><i 
              class="fas fa-tags fa-fw me-3"></i><span>Brands</span></a>
          <a href="items.php" class="list-group-item list-group-item-action py-2 ripple"><i 
              class="fas fa-box fa-fw me-3"></i></i><span>Items</span></a>
          <a href="remarks.php" class="list-group-item list-group-item-action py-2 ripple"><i 
              class="fas fa-clipboard fa-fw me-3"></i><span>Remarks</span></a>
        </div>
      </div>
    </nav>
    <!-- Sidebar -->