<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/mdb-ui-kit/6.4.1/mdb.min.js"></script>
  <!-- Custom scripts -->
  <script type="text/javascript" src="resources/js/admin.js"></script>

</body>

</html>