<?php include('database/dbcon.php'); ?>
<?php include_once('functions/fetch.php'); ?>
<?php
$all_users = find_all('users');
$all_items = find_all('items');
$all_categories = find_all('categories');
$all_brands = find_all('brands');
?>
<?php include_once('layouts/header.php'); ?>
<header>
    <?php include_once('layouts/sidebar.php'); ?>
    <?php include_once('layouts/navbar.php'); ?>
</header>
<main style="margin-top: 58px">
    <div class="container pt-4">
        <!--Section: Statistics with subtitles-->
        <section>
            <div class="row">
                <div class="col-xl-5 col-md-12 mb-4">
                    <div class="card">
                        <div class="card-header text-center py-3">
                            <h5 class="mb-0 text-center">
                                <strong>Add Items</strong>
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="post" class="clearfix" action="functions/items/add_items.php">
                                <div class="form-floating">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <label class="input-group-text" for="inputGroupSelectCategories">Category</label>
                                        </div>
                                        <select class="custom-select form-control" id="inputGroupSelectCategories" name="category_id">
                                            <option selected>Select Category...</option>
                                            <?php
                                            if ($all_categories !== null) {
                                                foreach ($all_categories as $cat) { ?>
                                                    <option value="<?php echo $cat['id'] ?>"><?php echo $cat['category'] ?></option>
                                            <?php   }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingModel" placeholder="Model" name="model">
                                    <label for="floatingModel">Model</label>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <label class="input-group-text" for="inputGroupSelectBrands">Brands</label>
                                        </div>
                                        <select class="custom-select form-control" id="inputGroupSelectBrands" name="brand_id">
                                            <option selected>Select Brand...</option>
                                            <?php
                                            if ($all_brands !== null) {
                                                foreach ($all_brands as $brand) { ?>
                                                    <option value="<?php echo  $brand['id'] ?>"><?php echo  $brand['brand'] ?></option>
                                            <?php   }
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingPurchasedValue" placeholder="Purchased Value" name="purchased_value">
                                    <label for="floatingPurchasedValue">Purchased Value</label>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingDescription" placeholder="Description" name="description">
                                    <label for="floatingPassword">Description</label>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingWarranty" placeholder="Warranty" name="warranty">
                                    <label for="floatingWarranty">Warranty</label>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="datetime-local" class="form-control" id="floatingDateAcquired" placeholder="Date Acquired" name="date_acquired">
                                    <label for="floatingDateAcquired">Date Acquired</label>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingISBN" placeholder="ISBN" name="ISBN">
                                    <label for="floatingISBN">Serial No./ISBN</label>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingPORefNo" placeholder="PO Ref No." name="PO_Ref_No">
                                    <label for="floatingPORefNo">PO Ref No.</label>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingLocation" placeholder="Location" name="location">
                                    <label for="floatingLocation">Location(Bldg/Flr)</label>
                                </div>
                                <br>
                                <div class="form-floating">
                                    <input type="text" class="form-control" id="floatingIssuedTo" placeholder="Issued To" name="issued_to">
                                    <label for="floatingIssuedTo">Issued To</label>
                                </div>
                                <br>
                                <button class="w-50 btn btn-md btn-success center" type="submit" name="submit">Add Item</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-md-12 mb-4">
                    <div class="card">
                        <div class="card-header text-center py-3">
                            <h5 class="mb-0 text-center">
                                <strong>All Items</strong>
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Category</th>
                                            <th scope="col">Model</th>
                                            <th scope="col">Brand</th>
                                            <th scope="col">Purchased Value</th>
                                            <th scope="col">Description</th>
                                            <th scope="col">Warranty</th>
                                            <th scope="col">Date Acquired</th>
                                            <th scope="col">Serial No./ISBN</th>
                                            <th scope="col">PO Ref No.</th>
                                            <th scope="col">Location(Bldg/Flr)</th>
                                            <th scope="col">Issued To</th>
                                            <th scope="col">Remarks</th>
                                            <th scope="col">Operation</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($all_items !== null) :
                                            foreach ($all_items as $item) : ?>
                                                <tr>
                                                    <td><?php echo $item['id']; ?></td>
                                                    <?php if ($all_categories !== null) { ?>
                                                        <?php foreach ($all_categories as $cat) :
                                                            if ($cat['id'] === $item['category_id']) {
                                                        ?>
                                                                <td><?php echo $cat['category']; ?></td>
                                                    <?php } elseif ($item['category_id'] === null) {
                                                                echo "<td>" . $item['category_id'] . "</td>";
                                                                break;
                                                            }
                                                        endforeach;
                                                    } else {
                                                        echo "<td>" . $item['category_id'] . "</td>";
                                                    } ?>
                                                    <td><?php echo $item['model']; ?></td>
                                                    <?php if ($all_brands !== null) { ?>
                                                        <?php foreach ($all_brands as $brand) :
                                                            if ($brand['id'] === $item['brand_id']) {
                                                        ?>
                                                                <td><?php echo $brand['brand']; ?></td>
                                                    <?php } elseif ($item['brand_id'] === null) {
                                                                echo "<td>" . $item['brand_id'] . "</td>";
                                                                break;
                                                            }
                                                        endforeach;
                                                    } else {
                                                        echo "<td>" . $item['brand_id'] . "</td>";
                                                    } ?>
                                                    <td><?php echo $item['purchased_value']; ?></td>
                                                    <td><?php echo $item['description']; ?></td>
                                                    <td><?php echo $item['warranty']; ?></td>
                                                    <td><?php echo $item['date_acquired']; ?></td>
                                                    <td><?php echo $item['ISBN']; ?></td>
                                                    <td><?php echo $item['PO_Ref_No']; ?></td>
                                                    <td><?php echo $item['location']; ?></td>
                                                    <td><?php echo $item['issued_to']; ?></td>
                                                    <td>
                                                        <button class="btn btn-primary btn-sm" aria-hidden="true"><i class="far fa-eye"></i></button>
                                                    </td>
                                                    <td>
                                                        <button class="btn btn-danger btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#deleteItems<?php echo $item['id']; ?>">DELETE</button>
                                                        <button class="btn btn-success btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#editItems<?php echo $item['id']; ?>">EDIT</button>
                                                    </td>
                                                </tr>

                                        <?php include("forms/items/edit_items.php");
                                                include("forms/items/delete_items.php");
                                            endforeach;
                                        endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Section: Statistics with subtitles-->
    </div>
</main>
<?php include_once('layouts/footer.php'); ?>