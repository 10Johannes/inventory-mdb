<?php
ob_start();
session_start();
require_once('database/dbcon.php');
require_once('functions/fetch.php');
$all_departments = find_all('departments');
$alertColor;
$alertMessage;
if (isset($_SESSION['loggedin']) && $_SESSION['loggedin'] == true) {
  echo "<script>window.location.href='admin.php';</script>";
} else {
  if (isset($_GET['message'])) {
    $params = $_GET['message'];
    if ($params === "incorrect") {
      $alertColor = "alert-danger";
      $alertMessage = "Incorrect username/password!";
    }
  } else {
    $alertColor = "alert-primary";
    $alertMessage = "Please login to proceed.";
  }
}
?>
<?php include_once('layouts/header.php'); ?>
<main class="form-modal">
  <br><br><br>
  <form method="post" action="functions/signin.php" class="clearfix">
    <img class="mb-4 center" src="resources/img/mycompass-logo.png" alt="COMPASS Logo">
    <h1 class="h3 mb-3 fw-normal text-center">Inventory System</h1>
    <div id="alert" class="alert <?php echo $alertColor; ?>"><?php echo $alertMessage; ?></div>
    <div class="form-floating">
      <input type="username" class="form-control" id="floatingInput" placeholder="Username" name="username" required>
      <label for="floatingInput">Username</label>
    </div>
    <br>
    <div class="form-floating">
      <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password" required>
      <label for="floatingPassword">Password</label>
    </div>
    <button class="w-100 btn btn-lg btn-primary" type="submit" name="submit">Sign in</button>
    <hr>
    <button class="w-75 btn btn-lg btn-success center" type="button" data-bs-toggle="modal" data-bs-target="#registerModal">Register</button>
  </form>
</main>

<!-- Modal -->
<div class="modal fade" id="registerModal" tabindex="-1" aria-labelledby="registerModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="registerModalLabel">Sign Up</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <main class="form-modal">
          <form method="post" class="clearfix" action="functions/register.php">
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingFirstName" placeholder="First Name" name="firstname" required>
              <label for="floatingFirstName">First Name</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="text" class="form-control" id="floatingLastName" placeholder="Last Name" name="lastname" required>
              <label for="floatingLastName">Last Name</label>
            </div>
            <br>
            <div class="form-floating">
              <div class="input-group">
                <div class="input-group-prepend">
                  <label class="input-group-text" for="inputGroupSelectDepartments">Departments</label>
                </div>
                <select class="custom-select form-control" id="inputGroupSelectDepartments" name="department">
                  <option selected>Select Departments...</option>
                  <?php
                  if ($all_departments !== null) {
                    foreach ($all_departments as $dept) { ?>
                      <option value="<?php echo  $dept['id'] ?>"><?php echo  $dept['department'] ?></option>
                  <?php   }
                  } ?>
                </select>
              </div>
            </div>
            <br>
            <div class="form-floating">
              <input type="username" class="form-control" id="floatingInput" placeholder="Username" name="username" required>
              <label for="floatingInput">Username</label>
            </div>
            <br>
            <div class="form-floating">
              <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password" required>
              <label for="floatingPassword">Password</label>
            </div>
            <br>
            <button class="w-50 btn btn-lg btn-success center" type="submit" name="submit">Sign Up</button>
          </form>
        </main>
      </div>
    </div>
  </div>
</div>
<?php include_once('layouts/footer.php'); ?>