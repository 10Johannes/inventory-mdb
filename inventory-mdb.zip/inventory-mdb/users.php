<?php include_once('database/dbcon.php'); ?>
<?php include_once('functions/fetch.php'); ?>
<?php
$all_users = find_all('users');
$all_departments = find_all('departments');
$all_privileges = find_all('privileges');
?>
<?php include_once('layouts/header.php'); ?>
<header>
  <?php include_once('layouts/sidebar.php'); ?>
  <?php include_once('layouts/navbar.php'); ?>
</header>
<main style="margin-top: 58px">
  <div class="container pt-4">
    <!--Section: Statistics with subtitles-->
    <section>
      <div class="row">
        <div class="col-xl-3 col-md-12 mb-4">
          <div class="card">
            <div class="card-header text-center py-3">
              <h5 class="mb-0 text-center">
                <strong>Add Users</strong>
              </h5>
            </div>
            <div class="card-body">
              <form method="post" class="clearfix" action="functions/register.php">
                <div class="form-floating">
                  <input type="text" class="form-control" id="floatingFirstName" placeholder="First Name" name="firstname" required>
                  <label for="floatingFirstName">First Name</label>
                </div>
                <br>
                <div class="form-floating">
                  <input type="text" class="form-control" id="floatingLastName" placeholder="Last Name" name="lastname" required>
                  <label for="floatingLastName">Last Name</label>
                </div>
                <br>
                <div class="form-floating">
                  <div class="input-group">
                    <div class="input-group-prepend">
                      <label class="input-group-text" for="inputGroupSelectDepartments">Departments</label>
                    </div>
                    <select class="custom-select form-control" id="inputGroupSelectDepartments" name="department">
                      <option selected>Select Departments...</option>
                      <?php
                      if ($all_departments !== null) {
                        foreach ($all_departments as $dept) { ?>
                          <option value="<?php echo  $dept['id'] ?>"><?php echo  $dept['department'] ?></option>
                      <?php   }
                      } ?>
                    </select>
                  </div>
                </div>
                <br>
                <div class="form-floating">
                  <input type="username" class="form-control" id="floatingInput" placeholder="Username" name="username" required>
                  <label for="floatingInput">Username</label>
                </div>
                <br>
                <div class="form-floating">
                  <input type="password" class="form-control" id="floatingPassword" placeholder="Password" name="password" required>
                  <label for="floatingPassword">Password</label>
                </div>
                <br>
                <button class="w-50 btn btn-lg btn-success center" type="submit" name="submit">Add User</button>
              </form>
            </div>
          </div>
        </div>
        <div class="col-xl-9 col-md-12 mb-4">
          <div class="card">
            <div class="card-header text-center py-3">
              <h5 class="mb-0 text-center">
                <strong>All Users</strong>
              </h5>
            </div>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered">
                  <thead>
                    <tr>
                      <th scope="col">#</th>
                      <th scope="col">First Name</th>
                      <th scope="col">Last Name</th>
                      <th scope="col">Department</th>
                      <th scope="col">Privilege</th>
                      <th scope="col">Username</th>
                      <th scope="col">Password</th>
                      <th scope="col">Operations</th>
                    </tr>
                  </thead>
                  <tbody>
                    <?php
                    if ($all_users !== null) :
                      foreach ($all_users as $user) : ?>
                        <tr>
                          <td><?php echo $user['id']; ?></td>
                          <td><?php echo $user['firstname']; ?></td>
                          <td><?php echo $user['lastname']; ?></td>
                          <?php if ($all_departments !== null){ ?>
                          <?php foreach ($all_departments as $dept) :
                            if ($dept['id'] === $user['department_id']){
                          ?>
                              <td><?php echo $dept['department']; ?></td>
                          <?php } elseif ($user['department_id'] === null) {
                            echo "<td>".$user['department_id']."</td>";
                            break;
                          }
                          endforeach;
                         } else {
                          echo "<td>".$user['department_id']."</td>";
                        } ?>
                          <?php if ($all_privileges !== null){ ?>
                          <?php foreach ($all_privileges as $privilege) :
                            if ($privilege['id'] === $user['privilege_id']){
                          ?>
                              <td><?php echo $privilege['privilege']; ?></td>
                          <?php } elseif ($user['privilege_id'] === null){
                            echo "<td>".$user['privilege_id']."</td>";
                            break;
                          }
                          endforeach;
                         } else {
                          echo "<td>".$user['privilege_id']."</td>";
                        } ?>
                          <td><?php echo $user['username']; ?></td>
                          <td><?php echo $user['password']; ?></td>
                          <td>
                            <button class="btn btn-danger btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#deleteUsers<?php echo $user['id']; ?>">DELETE</button>
                            <button class="btn btn-success btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#editUsers<?php echo $user['id']; ?>">EDIT</button>
                          </td>
                        </tr>

                    <?php include("forms/users/edit_users.php");
                        include("forms/users/delete_users.php");
                      endforeach;
                    endif;
                    ?>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <!--Section: Statistics with subtitles-->
  </div>
</main>
<?php include_once('layouts/footer.php'); ?>