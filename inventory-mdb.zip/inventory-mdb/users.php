<?php include_once('database/dbcon.php'); ?>
<?php include_once('functions/fetch.php'); ?>
<?php 
$all_users = find_all('users');
?>
<?php include_once('layouts/header.php'); ?>
<header>
    <?php include_once('layouts/sidebar.php'); ?>
    <?php include_once('layouts/navbar.php'); ?>
</header>
<main style="margin-top: 58px">
    <div class="container pt-4">
    <!--Section: Statistics with subtitles-->
    <section>
        <div class="row">
          <div class="col-xl-3 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>Add Users</strong>
                </h5>
            </div>
              <div class="card-body">
                <form method="post" class="clearfix" action="functions/categories/add_categories.php">
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" placeholder="Category Name" aria-label="Category Name" aria-describedby="add-category-button" name="category" pattern="[a-zA-Z]{}" required>
                        <button class="btn btn-success" type="submit" id="add-category-button" name="submit">Add</button>
                    </div>
                </form>
              </div>
            </div>
          </div>
          <div class="col-xl-9 col-md-12 mb-4">
            <div class="card">
            <div class="card-header text-center py-3">
                <h5 class="mb-0 text-center">
                    <strong>All Categories</strong>
                </h5>
            </div>
              <div class="card-body">
              <div class="table-responsive">
              <table class="table table-hover text-nowrap">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Category Name</th>
                        <th scope="col">Operations</th>
                    </tr>
                </thead>
                <tbody>
                <?php 
                  if($all_categories !== null):
                    foreach ($all_categories as $cat):?>
                    <tr>
                    <td><?php echo $cat['id'];?></td>
                    <td><?php echo $cat['category'];?></td>
                        <td>
                            <button  class="btn btn-danger btn-sm" aria-hidden="true"  data-bs-toggle="modal" data-bs-target="#deleteCategories<?php echo $cat['id'];?>">DELETE</button>
                            <button class="btn btn-success btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#editCategories<?php echo $cat['id'];?>" >EDIT</button>
                        </td>
                    </tr>
                    
                    <?php include("forms/categories/edit_categories.php");
                          include("forms/categories/delete_categories.php");
                           endforeach;
                            ?>
                <?php 
                  endif; ?>
                </tbody>
              </table>
            </div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <!--Section: Statistics with subtitles-->
    </div>
</main>
<?php include_once('layouts/footer.php'); ?>