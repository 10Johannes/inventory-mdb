<?php include('database/dbcon.php'); ?>
<?php include_once('functions/fetch.php'); ?>
<?php
$all_users = find_all('users');
$all_items = find_all('items');
$all_categories = find_all('categories');
$all_brands = find_all('brands');
$all_remarks = find_all('remarks');
?>
<?php include_once('layouts/header.php'); ?>
<header>
    <?php include_once('layouts/sidebar.php'); ?>
    <?php include_once('layouts/navbar.php'); ?>
</header>
<main style="margin-top: 58px">
    <div class="container pt-4">
        <!--Section: Statistics with subtitles-->
        <section>
            <div class="row">
                <div class="col-xl-5 col-md-12 mb-4">
                    <div class="card">
                        <div class="card-header text-center py-3">
                            <h5 class="mb-0 text-center">
                                <strong>Add Remarks</strong>
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="post" class="clearfix" action="functions/remarks/add_remarks.php">
                                <div class="input-group mb-3">
                                    <span class="input-group-text" id="inputGroupItemID">Item ID:  </span>
                                    <input type="text" class="form-control" aria-label="Item ID" aria-describedby="inputGroupItemID" name="item_id"/>
                                </div>
                                <div class="form-floating mb-3">
                                    <input type="datetime-local" class="form-control" id="floatingRemarkDate" placeholder="Remark Date" name="remark_date">
                                    <label for="floatingRemarkDate">Remark Date:</label>
                                </div>
                                <div class="form-outline">
                                    <textarea class="form-control" id="itemRemark" rows="4" name="remark"></textarea>
                                    <label class="form-label" for="itemRemark"><strong>Item Remark:</strong></label>
                                </div>
                                <br>
                                <button type="submit" class="btn btn-primary btn-md" name="submit">Add</button>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-xl-7 col-md-12 mb-4">
                    <div class="card">
                        <div class="card-header text-center py-3">
                            <h5 class="mb-0 text-center">
                                <strong>All Remarks</strong>
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th scope="col">#</th>
                                            <th scope="col">Item ID</th>
                                            <th scope="col">Remarks</th>
                                            <th scope="col">Remarks Date</th>
                                            <th scope="col">Operations</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if ($all_remarks !== null) :
                                            foreach ($all_remarks as $remark) : ?>
                                                <tr>
                                                    <td><?php echo $remark['id']; ?></td>
                                                    <td><?php echo $remark['item_id']; ?></td>
                                                    <td><?php echo $remark['remark']; ?></td>
                                                    <td><?php echo $remark['remark_date']; ?></td>
                                                    <td>
                                                        <button class="btn btn-danger btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#deleteRemarks<?php echo $remark['id']; ?>">DELETE</button>
                                                        <button class="btn btn-success btn-sm" aria-hidden="true" data-bs-toggle="modal" data-bs-target="#editRemarks<?php echo $remark['id']; ?>">EDIT</button>
                                                    </td>
                                                </tr>

                                            <?php include("forms/remarks/edit_remarks.php");
                                                include("forms/remarks/delete_remarks.php");
                                            endforeach;
                                            ?>
                                        <?php
                                        endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--Section: Statistics with subtitles-->
    </div>
</main>
<?php include_once('layouts/footer.php'); ?>